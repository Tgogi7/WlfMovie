# WlfMovie V6.4.0 — Compartir película DESCARGADA al PC (sin internet, red local / hotspot)

ZIP ACUMULATIVO: contiene TODO lo de v6.3.6 + estos cambios.
Copie la carpeta `app/` completa sobre la raíz de su proyecto (reemplaza archivos).

Si ya tiene v6.3.6 compilado, copie estos **5 archivos** (1 NUEVO + 4 modificados):
1. `app/src/main/java/com/mew/wlfmovie/remoteplay/LocalMediaPlaylist.kt` ← **NUEVO** (obligatorio)
2. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayState.kt`
3. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayServer.kt`
4. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayController.kt`
5. `app/src/main/java/com/mew/wlfmovie/fragments/player/PlayerMobileFragment.kt`

(Los otros archivos de `remoteplay/` incluidos en el zip —RemotePlayService,
RemotePlayFragment, VideoProxy— NO cambiaron; están solo para referencia completa.)

## El objetivo

Se va la luz → se va el internet → usted tiene su PC y su celular en la misma
red (el WiFi del router, o el **hotspot del celular**) → abre en el PC la URL
que muestra WlfMovie → y ve la película que tiene **descargada** en el celular.
Cero internet: el video viaja del almacenamiento del teléfono al PC por la
red local, nada más.

## Antes esto directamente FALLABA

Si compartías al PC una película descargada, el servidor intentaba
"retransmitir" un `file:///...` con OkHttp — que solo acepta http/https.
El PC recibía "No se pudo conectar al source". La puerta no existía.

## Qué se implementó

### 1. Mismo botón, motor distinto (detección automática)
El botón "Enviar a PC" es el mismo. Si el video que está reproduciendo es una
descarga (`file://`), el servidor cambia de modo SOLO:
- **Online**: funciona exactamente igual que siempre — retransmite la URL del
  provider con sus headers. Ni una línea cambió en ese camino.
- **Descarga**: sirve el archivo del disco directamente por la LAN.
  No se toca el VideoProxy ni internet.

### 2. El truco técnico: playlist m3u8 SINTÉTICA (`LocalMediaPlaylist.kt` NUEVO)
Sus descargas HLS son archivos `.ts` — y un navegador NO reproduce un `.ts`
crudo. En vez de convertir (lento, gastaría espacio extra), se genera al
vuelo un m3u8 que "envuelve" el archivo en segmentos virtuales por rango de
bytes (`#EXT-X-BYTERANGE`):
- El PC ya carga **hls.js** (el mismo del modo online) → pide cada rango al
  celular con header `Range` → el celular lee SOLO esos bytes del disco →
  hls.js los demuxa en el navegador. Play, pausa y seek funcionan igual.
- Detecta el formato solo: **MPEG-TS clásico** (paquetes de 188 bytes,
  segmentos alineados al sync byte) o **fMP4/CMAF** (lee las cajas MP4 y
  corta exactamente en cada `moof`, con `#EXT-X-MAP` para el init).
- **Descargas viejas .mp4** (de Remux): se sirven directo con soporte Range —
  el navegador lo reproduce nativo, seek instantáneo.
- La duración de la barra del PC sale del player del celular (ExoPlayer ya
  la conoce); hls.js la ajusta solo al demuxar.

### 3. Progreso 100% LOCAL (como pediste)
| | Online (igual que siempre) | Descarga (nuevo) |
|---|---|---|
| Guarda en | tabla movies/episodes | **solo tabla downloads** |
| Continuar viendo | sí | **ni se toca** |
| Sync a la nube (autoUpload) | cada 10s | **jamás se llama** |
| Al terminar | marca vista + sync | `isWatched` **local** de la descarga |

- El PC reporta posición cada 10s → se guarda en `downloads.watchPositionMillis`
  → la barra de progreso de la sección **Descargas** avanza en vivo.
- Al reabrir la película en el celular, retoma desde ahí (branch offline V6.3.1).
- `SyncManager` jamás se entera: sin internet no hay ni un intento de
  request externo que pueda fallar o colgar.

### 4. Diálogo distinto para que se sepa en qué modo está
En descargas dice: **"💻 Enviar descarga al PC"** — "funciona SIN internet
(red local/hotspot). El progreso se guarda solo en Descargas, nada de nube."

## Cómo probar (el test del apagón)

1. Descargue una película (HLS, la mayoría) y ábrala en el player.
2. Toque "Enviar a PC" → el diálogo debe decir "Enviar descarga al PC".
3. **Prueba fuego**: active modo avión en el celular + hotspot (o el router
   sin internet) → conecte el PC al WiFi del celular → abra la URL en el
   navegador → la película debe reproducir.
4. Adelante/retroceda en el PC → seek debe responder.
5. Vea unos minutos → detenga → en la app, sección Descargas: la barra de
   progreso de esa película debe haber avanzado.
6. Con internet: comparta una película ONLINE → todo debe funcionar
   exactamente como en v6.3.6 (retransmisión normal, progreso en
   continuar viendo, sync).

## Logs útiles
```
RemotePlayCtrl  start: modo LOCAL (descarga) — archivo=/data/.../movie_123.ts, downloadId=123
LocalPlaylist   sniffIsFmp4: fMP4 detectado (caja inicial 'ftyp')     ← o MPEG-TS
LocalPlaylist   buildTs: 1050 segmentos TS alineados a 188B, archivo=4294967296B
RemoteServer    serveFileRange: movie_123.ts, len=4294967296, range=bytes=0-524143
RemotePlayCtrl  saveLocalDownloadPosition: download=123 pos=61000/7200000 watched=false (solo local, sin sync)
```

## Nota
El primer arranque en el PC puede tardar 1-2s (hls.js demuxa el primer
segmento); después fluye igual que online. El primer segmento es chico
(512KB) precisamente para que el video arranque rápido.
