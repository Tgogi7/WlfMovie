package com.mew.wlfmovie.activities.main

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.navOptions
import com.bumptech.glide.Glide
import com.tanasi.navigation.widget.setupWithNavController
import com.mew.wlfmovie.BuildConfig
import com.mew.wlfmovie.R
import com.mew.wlfmovie.databinding.ActivityMainTvBinding
import com.mew.wlfmovie.databinding.ContentHeaderMenuMainTvBinding
import com.mew.wlfmovie.fragments.player.PlayerTvFragment
import com.mew.wlfmovie.ui.UpdateAppTvDialog
import com.mew.wlfmovie.providers.IptvProvider
import com.mew.wlfmovie.providers.Provider
import com.mew.wlfmovie.utils.AppLanguageManager
import com.mew.wlfmovie.utils.ThemeManager
import androidx.core.content.ContextCompat
import com.mew.wlfmovie.utils.UserPreferences
import com.mew.wlfmovie.utils.getCurrentFragment
import kotlinx.coroutines.launch

class MainTvActivity : FragmentActivity() {

    private var _binding: ActivityMainTvBinding? = null
    private val binding get() = _binding!!

    private val viewModel by viewModels<MainViewModel>()

    private var updateAppDialog: UpdateAppTvDialog? = null

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(AppLanguageManager.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(ThemeManager.tvThemeRes(UserPreferences.selectedTheme))

        super.onCreate(savedInstanceState)

        // WLFMOVIE V3: Verificar actualizaciones al arranque.
        lifecycleScope.launch {
            val blocked = com.mew.wlfmovie.utils.UpdateHelper.checkAndBlockIfRequired(this@MainTvActivity)
            if (blocked) { finish(); return@launch }
            // WLFMOVIE V4: Auto-download si el servidor tiene datos más recientes
            com.mew.wlfmovie.utils.SyncManager.autoDownloadIfNewer(this@MainTvActivity)
        }

        // WLFMOVIE V6.2: Mostrar el LastCrashDialog si hubo un crash fatal
        // en la ejecucion anterior y el usuario aun no lo ha visto.
        // Solo en DEBUG — en release no se persisten crashes ni se muestran
        // popups al usuario final.
        if (com.mew.wlfmovie.BuildConfig.DEBUG) {
            try {
                if (com.mew.wlfmovie.utils.CrashLogger.hasUnreadCrash()) {
                    com.mew.wlfmovie.ui.LastCrashDialog.show(
                        context = this,
                        onViewAll = {
                            val count = com.mew.wlfmovie.utils.CrashLogger.count()
                            val text = com.mew.wlfmovie.utils.CrashLogger.getErrorsAsText()
                            showCollectedErrorsDialog(count, text)
                        },
                        onDismiss = { /* no-op */ },
                    )
                }
            } catch (t: Throwable) {
                Log.e("WlfMovie-App", "No se pudo mostrar LastCrashDialog", t)
            }
        }

        // WLFMOVIE: Forzar TMDB (es) como provider al arranque.
        // No importa lo que el user tenia guardado — siempre TMDB.
        if (UserPreferences.currentProvider == null) {
            Log.i("WlfMovie-TV", "Provider era null, forzando TMDb (es)")
        }

        // WLFMOVIE: Eliminadas las llamadas a AnimeOnlineNinjaProvider.init(),
        // Cine24hProvider.init() y FilmyOnlineCcProvider.init().
        // Esos providers NO estan en la lista de providers que usa TmdbProvider
        // para buscar en paralelo al reproducir (ver Provider.providers en
        // Provider.kt). Eran residuos del codigo original StreamFlix.

        _binding = ActivityMainTvBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyThemeNavigationChrome()

        // WLFMOVIE V4: Indicador de nube (después de que el binding está listo)

        binding.ivSplashOverlay.animate()
            .alpha(0f)
            .setDuration(800)
            .setStartDelay(400)
            .withEndAction {
                // WLFMOVIE: Proteger contra NPE si la activity fue destruida
                // (ej: update check bloqueó la app mientras la animación corría).
                _binding?.ivSplashOverlay?.visibility = View.GONE
            }

        val navHostFragment = this.supportFragmentManager
            .findFragmentById(binding.navMainFragment.id) as NavHostFragment
        val navController = navHostFragment.navController

        adjustLayoutDelta(null, null)

        if (BuildConfig.APP_LAYOUT == "mobile" ||
            (BuildConfig.APP_LAYOUT != "tv" &&
                !packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK))
        ) {
            finish()
            startActivity(Intent(this, MainMobileActivity::class.java))
            return
        }

        if (savedInstanceState == null) {
            // WLFMOVIE: Siempre navegar al home — currentProvider siempre
            // devuelve TMDb (es), asi que esto siempre se ejecuta.
            UserPreferences.currentProvider?.let {
                navController.navigate(R.id.home)
            }
        }

        binding.navMain.setupWithNavController(navController)
        updateNavigationVisibility()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            binding.navMainFragment.isFocusedByDefault = true
        }

        navController.addOnDestinationChangedListener { _, destination, _ ->
            binding.navMain.headerView?.apply {
                val header = ContentHeaderMenuMainTvBinding.bind(this)

                Glide.with(context)
                    .load(R.drawable.ic_wlfmovie_logo)
                    .error(R.drawable.ic_provider_default_logo)
                    .into(header.ivNavigationHeaderIcon)
                header.tvNavigationHeaderTitle.text = "WlfMovie"
                header.tvNavigationHeaderSubtitle.text = getString(R.string.main_menu_settings)
                // WLFMOVIE: Colores fijos WlfMovie (no dependen del tema).
                header.tvNavigationHeaderTitle.setTextColor(0xFFFFFFFF.toInt())
                header.tvNavigationHeaderSubtitle.setTextColor(0xFFB8B8D1.toInt())

                setOnOpenListener {
                    header.tvNavigationHeaderTitle.visibility = View.VISIBLE
                    header.tvNavigationHeaderSubtitle.visibility = View.VISIBLE
                }
                setOnCloseListener {
                    header.tvNavigationHeaderTitle.visibility = View.GONE
                    header.tvNavigationHeaderSubtitle.visibility = View.GONE
                }

                setOnClickListener {
                    // WLFMOVIE V4: ir a Settings al click en el logo del header.
                    navController.navigate(R.id.settings)
                }
            }

            // WLFMOVIE: misma logica que mobile — mostrar nav lateral en
            // destinos top-level.
            when (destination.id) {
                R.id.search, R.id.home, R.id.movies, R.id.tv_shows, R.id.lists, R.id.settings -> {
                    binding.navMain.visibility = View.VISIBLE
                    updateNavigationVisibility()
                }
                else -> binding.navMain.visibility = View.GONE
            }

        }

        lifecycleScope.launch {
            viewModel.state.flowWithLifecycle(lifecycle, Lifecycle.State.STARTED).collect { state ->
                when (state) {
                    is MainViewModel.State.SuccessCheckingUpdate -> showUpdateDialog(state)
                    MainViewModel.State.DownloadingUpdate -> updateAppDialog?.isLoading = true
                    is MainViewModel.State.SuccessDownloadingUpdate -> {
                        viewModel.installUpdate(this@MainTvActivity, state.apk)
                        dismissUpdateDialog()
                    }
                    MainViewModel.State.InstallingUpdate -> updateAppDialog?.isLoading = true
                    is MainViewModel.State.FailedUpdate -> {
                        updateAppDialog?.isLoading = false
                        Toast.makeText(
                            this@MainTvActivity,
                            state.error.message ?: "Update failed",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else -> {}
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (navController.currentDestination?.id) {
                    R.id.home -> if (binding.navMain.hasFocus()) finish() else binding.navMain.requestFocus()
                    R.id.search, R.id.movies, R.id.tv_shows, R.id.lists, R.id.settings -> {
                        navigateToProviderHome(navController)
                        binding.navMain.requestFocus()
                    }
                    else -> {
                        val handled = (getCurrentFragment() as? PlayerTvFragment)?.onBackPressed() ?: false
                        if (!handled && !navController.navigateUp()) finish()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkUpdate()
    }

    override fun onDestroy() {
        dismissUpdateDialog()
        _binding = null
        super.onDestroy()
    }

    private fun showUpdateDialog(state: MainViewModel.State.SuccessCheckingUpdate) {
        if (isFinishing || isDestroyed) return

        dismissUpdateDialog()
        updateAppDialog = UpdateAppTvDialog(this@MainTvActivity, state.newReleases).also { dialog ->
            dialog.setOnUpdateClickListener {
                if (!dialog.isLoading) {
                    viewModel.downloadUpdate(this@MainTvActivity, state.asset)
                }
            }
            dialog.show()
        }
    }

    private fun dismissUpdateDialog() {
        updateAppDialog?.takeIf { it.isShowing }?.dismiss()
        updateAppDialog = null
    }

    private fun applyThemeNavigationChrome() {
        // WLFMOVIE: Fondo morado fijo para el nav lateral (no depende del tema).
        val navBg = ContextCompat.getDrawable(this, R.drawable.wlf_bg_details_fragment)
        window.statusBarColor = 0x00000000
        window.navigationBarColor = 0x00000000
        binding.navMain.background = navBg
        binding.navMain.headerView?.let { headerView ->
            headerView.background = navBg
            val header = ContentHeaderMenuMainTvBinding.bind(headerView)
            header.tvNavigationHeaderTitle.setTextColor(0xFFFFFFFF.toInt())
            header.tvNavigationHeaderSubtitle.setTextColor(0xFFB8B8D1.toInt())
        }
    }

    private fun updateNavigationVisibility() {
        UserPreferences.currentProvider?.let { provider ->
            binding.navMain.menu.findItem(R.id.movies)?.isVisible = Provider.supportsMovies(provider)
            val tvShowsItem = binding.navMain.menu.findItem(R.id.tv_shows)
            tvShowsItem?.isVisible = Provider.supportsTvShows(provider)
            tvShowsItem?.title = if (provider is IptvProvider)
                getString(R.string.main_menu_all_channels) else getString(R.string.main_menu_tv_shows)
        }
    }

    fun adjustLayoutDelta(deltaX: Int?, deltaY: Int?) {
        val uDeltaX = deltaX ?: UserPreferences.paddingX
        val uDeltaY = deltaY ?: UserPreferences.paddingY
        binding.root.setPadding(uDeltaX, uDeltaY, uDeltaX, uDeltaY)
    }

    private fun navigateToProviderHome(navController: androidx.navigation.NavController) {
        if (!navController.popBackStack(R.id.home, false)) {
            navController.navigate(
                R.id.home,
                null,
                navOptions {
                    launchSingleTop = true
                    popUpTo(R.id.providers) {
                        inclusive = true
                    }
                }
            )
        }
    }

    /**
     * WLFMOVIE V6.2: Dialogo completo del recopilador de errores (TV).
     * Botones: Copiar todo / Borrar / Cerrar.
     */
    private fun showCollectedErrorsDialog(count: Int, fullText: String) {
        val message = if (count == 0) {
            getString(R.string.debug_errors_empty)
        } else {
            getString(R.string.debug_errors_dialog_title, count) + "\n\n" +
                fullText.take(20_000)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.debug_errors_dialog_title, count))
            .setMessage(message)
            .setPositiveButton(R.string.debug_errors_clear) { _, _ ->
                android.app.AlertDialog.Builder(this)
                    .setTitle(R.string.debug_errors_clear_confirm)
                    .setPositiveButton(R.string.debug_errors_clear_yes) { _, _ ->
                        com.mew.wlfmovie.utils.CrashLogger.clear()
                        android.widget.Toast.makeText(
                            this,
                            R.string.debug_errors_clear_done,
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                    .setNegativeButton(R.string.debug_errors_clear_no, null)
                    .show()
            }
            .setNegativeButton(R.string.debug_errors_copy_all) { _, _ ->
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                    as android.content.ClipboardManager
                clipboard.setPrimaryClip(
                    android.content.ClipData.newPlainText("WlfMovie Errors", fullText)
                )
                android.widget.Toast.makeText(
                    this,
                    R.string.debug_errors_copied_toast,
                    android.widget.Toast.LENGTH_SHORT,
                ).show()
            }
            .setNeutralButton(android.R.string.cancel, null)
            .show()
    }
}
