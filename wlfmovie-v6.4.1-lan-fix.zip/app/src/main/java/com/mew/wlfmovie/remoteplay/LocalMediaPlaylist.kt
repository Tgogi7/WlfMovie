package com.mew.wlfmovie.remoteplay

import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

/**
 * WLFMOVIE V6.4.1 — Generador de playlist m3u8 SINTETICA para compartir una
 * pelicula DESCARGADA al PC por la red local (sin internet).
 *
 * El archivo descargado por HLS es un `.ts` — concatenacion de segmentos:
 * - MPEG-TS clasico (paquetes de 188 bytes empezando con 0x47), o
 * - fMP4/CMAF (init.mp4 + seg_N.m4s concatenados → cajas MP4: ftyp/moov/moof/mdat...)
 *
 * Un navegador de PC NO puede reproducir un `.ts` crudo en un <video>, pero el
 * reproductor web del PC ya carga hls.js — asi que generamos un m3u8 que
 * "envuelve" el archivo local en segmentos virtuales.
 *
 * ---------------------------------------------------------------------------
 * V6.4.0 (fallaba) — segmentos por #EXT-X-BYTERANGE sobre /localfile:
 *   El problema: solo el PRIMER trozo del archivo contiene los paquetes
 *   PAT/PMT (el "mapa" de pistas del MPEG-TS). hls.js reinicia su demuxer TS
 *   en varios escenarios (reintento de error, recuperacion, seek), y al
 *   reiniciar pierde el mapeo PID→pista → "Found no media in fragment N"
 *   (fragParsingError) a los 2-3 segundos de reproduccion.
 *
 * V6.4.1 (esta version) — segmentos AUTOCONTENIDOS via URLs dedicadas:
 *   1. Se parsea el PAT/PMT REAL del archivo (PIDs y stream_types exactos).
 *   2. Se sintetizan 2 paquetes PSI (PAT + PMT, con CRC32-MPEG valido) que se
 *      ANTEPONEN a cada segmento servido en /localsegment?i=N → cada
 *      segmento es un segmento HLS TS valido e independiente, igual que los
 *      de un HLS real. El demuxer puede reiniciarse mil veces: siempre
 *      reencuentra el mapa de pistas.
 *   3. Las duraciones #EXTINF se calculan con los timestamps PCR reales del
 *      inicio de cada segmento (no uniformes) → seek preciso en el PC, y el
 *      total se normaliza a la duracion que conoce el player de Android.
 *   4. fMP4/CMAF: segmento init via #EXT-X-MAP (URL dedicada), fragmentos
 *      agrupados por cajas moof/mdat, duraciones por tfdt (timescale del
 *      track de video).
 *
 * Cero cambios en la web del PC y cero internet: todo se sirve del disco.
 */
object LocalMediaPlaylist {

    private const val TAG = "WlfMovie-LocalPlaylist"

    private const val TS_PACKET = 188

    /** Paquetes TS por segmento (~4.1 MB): balance requests / precision de seek. */
    private const val TS_PACKETS_PER_SEGMENT = 22000

    /** Primer segmento (~550 KB) para que el video arranque rapido en el PC. */
    private const val TS_PACKETS_FIRST_SEGMENT = 3000

    /** Ventana maxima para buscar un paquete PCR al inicio de cada segmento. */
    private const val PCR_SCAN_LIMIT_BYTES = 256L * 1024
    private const val PCR_SCAN_CHUNK_BYTES = 64 * 1024

    /** Ventana para parsear PAT/PMT al inicio del archivo. */
    private const val PSI_SCAN_BYTES = 1024 * 1024

    /** Maximo de streams copiados al PMT sintetico (limite fisico del paquete). */
    private const val MAX_SYNTH_STREAMS = 30

    private const val DEFAULT_SEGMENT_DURATION_SEC = 6.0
    private const val MIN_SANE_SEGMENT_SEC = 0.05
    private const val MAX_SANE_SEGMENT_SEC = 120.0

    /** Target de bytes por segmento fMP4 (agrupa fragmentos CMAF vecinos). */
    private const val FMP4_GROUP_TARGET_BYTES = 4L * 1024 * 1024

    // ================================================================
    // Resultado de la indexacion
    // ================================================================

    class Segment(val offset: Long, val length: Long)

    class LocalIndex(
        /** true = fMP4/CMAF, false = MPEG-TS. */
        val isFmp4: Boolean,
        /** Segmentos en bytes del archivo (sin el prologo sintetico). */
        val segments: List<Segment>,
        /** Duracion en segundos de cada segmento (mismo orden que [segments]). */
        val durationsSec: List<Double>,
        /** TS: paquetes PAT+PMT sinteticos (376B) a anteponer a cada segmento. */
        val tsPrologue: ByteArray?,
        /** fMP4: fin exclusivo del segmento de inicializacion (0 = sin init). */
        val fmp4InitEnd: Long,
        val totalDurationSec: Double,
    )

    /**
     * Parsea el archivo y construye el indice de segmentos.
     * @return null si el archivo no se puede indexar → el llamador debe usar
     *         [buildLegacyByterangeM3u8] como ultimo recurso.
     */
    fun buildIndex(file: File, knownDurationMs: Long): LocalIndex? {
        val fileLen = file.length()
        if (!file.exists() || fileLen <= 0L) {
            Log.e(TAG, "buildIndex: archivo inexistente o vacio: ${file.path}")
            return null
        }
        return try {
            if (sniffIsFmp4(file)) {
                buildFmp4Index(file, fileLen, knownDurationMs)
            } else {
                buildTsIndex(file, fileLen, knownDurationMs)
            }
        } catch (e: Exception) {
            Log.e(TAG, "buildIndex: error", e)
            null
        }
    }

    /**
     * Genera el m3u8 con URLs dedicadas por segmento:
     *   {baseUrl}/localsegment?i=N        (N = 0..segments-1)
     *   {baseUrl}/localsegment?i=init     (segmento de inicializacion fMP4)
     */
    fun buildM3u8(index: LocalIndex, baseUrl: String): String {
        val sb = StringBuilder()
        sb.append("#EXTM3U\n")
        sb.append("#EXT-X-VERSION:6\n")
        sb.append("#EXT-X-PLAYLIST-TYPE:VOD\n")
        sb.append("#EXT-X-MEDIA-SEQUENCE:0\n")
        sb.append("#EXT-X-TARGETDURATION:").append(targetDuration(index.durationsSec)).append('\n')
        if (index.isFmp4 && index.fmp4InitEnd > 0L) {
            sb.append("#EXT-X-MAP:URI=\"").append(baseUrl).append("/localsegment?i=init\"\n")
        }
        for (i in index.segments.indices) {
            sb.append("#EXTINF:").append(String.format(Locale.US, "%.3f", index.durationsSec[i])).append(",\n")
            sb.append(baseUrl).append("/localsegment?i=").append(i).append('\n')
        }
        sb.append("#EXT-X-ENDLIST\n")
        return sb.toString()
    }

    /**
     * ULTIMO RECURSO (archivo no indexable): el m3u8 por rango de bytes de la
     * V6.4.0. Se mantiene para no regresar nunca un error donde antes habia
     * "algo", aunque la reproduccion no esta garantizada.
     */
    fun buildLegacyByterangeM3u8(file: File, fileUrl: String, knownDurationMs: Long): String {
        val fileLen = file.length()
        val firstLen = alignDown(512L * 1024)
        val segLen = alignDown(4L * 1024 * 1024)

        val segs = ArrayList<Segment>()
        var start = 0L
        while (start < fileLen) {
            val size = if (segs.isEmpty()) firstLen else segLen
            val endExclusive = minOf(start + size, fileLen)
            segs.add(Segment(start, endExclusive - start))
            start = endExclusive
        }
        val n = segs.size
        val durationSec = if (knownDurationMs > 0) (knownDurationMs / 1000.0) / n else DEFAULT_SEGMENT_DURATION_SEC

        val sb = StringBuilder()
        sb.append("#EXTM3U\n")
        sb.append("#EXT-X-VERSION:4\n")
        sb.append("#EXT-X-PLAYLIST-TYPE:VOD\n")
        sb.append("#EXT-X-MEDIA-SEQUENCE:0\n")
        sb.append("#EXT-X-TARGETDURATION:").append(targetDuration(List(n) { durationSec })).append('\n')
        for (seg in segs) {
            sb.append("#EXTINF:").append(String.format(Locale.US, "%.3f", durationSec)).append(",\n")
            sb.append("#EXT-X-BYTERANGE:").append(seg.length).append('@').append(seg.offset).append('\n')
            sb.append(fileUrl).append('\n')
        }
        sb.append("#EXT-X-ENDLIST\n")
        return sb.toString()
    }

    // ================================================================
    // Deteccion de formato
    // ================================================================

    private val FMP4_FIRST_BOXES = setOf("ftyp", "styp", "moov", "moof", "sidx", "free", "skip", "pdin", "uuid")

    private fun sniffIsFmp4(file: File): Boolean {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val header = ByteArray(8)
                var n = 0
                while (n < header.size) {
                    val r = raf.read(header, n, header.size - n)
                    if (r < 0) break
                    n += r
                }
                if (n < 8) return false
                // sync byte MPEG-TS → definitivamente TS
                if (header[0].toInt() == 0x47) return false
                val boxType = String(header, 4, 4, Charsets.US_ASCII)
                val fmp4 = boxType in FMP4_FIRST_BOXES
                if (fmp4) Log.i(TAG, "sniffIsFmp4: fMP4 detectado (caja inicial '$boxType')")
                fmp4
            }
        } catch (e: Exception) {
            Log.e(TAG, "sniffIsFmp4: error, asumiendo MPEG-TS", e)
            false
        }
    }

    // ================================================================
    // MPEG-TS: parseo de PAT/PMT/PCR
    // ================================================================

    private class TsProgram(val pmtPid: Int, val pcrPid: Int, val streams: List<Pair<Int, Int>>)

    private fun pidOf(buf: ByteArray, pos: Int): Int =
        ((buf[pos + 1].toInt() and 0x1F) shl 8) or (buf[pos + 2].toInt() and 0xFF)

    /** Busca el PAT (PID 0) y el PMT en el primer MB del archivo. */
    private fun parseTsProgram(file: File): TsProgram? {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val windowLen = minOf(PSI_SCAN_BYTES.toLong(), raf.length()).toInt()
                if (windowLen < TS_PACKET) return null
                val buf = ByteArray(windowLen)
                raf.seek(0L)
                raf.readFully(buf)

                // 1) PAT → PID del PMT
                var pmtPid = -1
                var pos = 0
                while (pos + TS_PACKET <= windowLen && pmtPid < 0) {
                    if (buf[pos].toInt() == 0x47 && pidOf(buf, pos) == 0) {
                        pmtPid = parsePatPmtPid(buf, pos) ?: -1
                    }
                    pos += TS_PACKET
                }
                if (pmtPid < 0) return null

                // 2) PMT → PCR PID + streams (seguir escaneando si el primer
                // paquete del PID es una continuacion sin PUSI)
                pos = 0
                while (pos + TS_PACKET <= windowLen) {
                    if (buf[pos].toInt() == 0x47 && pidOf(buf, pos) == pmtPid) {
                        val pmt = parsePmt(buf, pos, pmtPid)
                        if (pmt != null) return pmt
                    }
                    pos += TS_PACKET
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "parseTsProgram: error", e)
            null
        }
    }

    /** PAT en el paquete [pos] (PID 0) → PID del PMT. */
    private fun parsePatPmtPid(buf: ByteArray, pos: Int): Int? {
        if (buf[pos + 1].toInt() and 0x40 == 0) return null   // sin PUSI
        val pointer = buf[pos + 4].toInt() and 0xFF
        val s = pos + 5 + pointer
        if (s + 8 > pos + TS_PACKET) return null
        if (buf[s].toInt() != 0x00) return null               // table_id = PAT
        val sectionLength = ((buf[s + 1].toInt() and 0x0F) shl 8) or (buf[s + 2].toInt() and 0xFF)
        var p = s + 8
        val end = minOf(s + 3 + sectionLength - 4, pos + TS_PACKET)
        while (p + 4 <= end) {
            val programNumber = ((buf[p].toInt() and 0xFF) shl 8) or (buf[p + 1].toInt() and 0xFF)
            val pid = ((buf[p + 2].toInt() and 0x1F) shl 8) or (buf[p + 3].toInt() and 0xFF)
            if (programNumber != 0) return pid
            p += 4
        }
        return null
    }

    /** PMT en el paquete [pos] → PCR PID + lista de (stream_type, PID). */
    private fun parsePmt(buf: ByteArray, pos: Int, pmtPid: Int): TsProgram? {
        if (buf[pos + 1].toInt() and 0x40 == 0) return null   // sin PUSI
        val pointer = buf[pos + 4].toInt() and 0xFF
        val s = pos + 5 + pointer
        if (s + 12 > pos + TS_PACKET) return null
        if (buf[s].toInt() != 0x02) return null               // table_id = PMT
        val sectionLength = ((buf[s + 1].toInt() and 0x0F) shl 8) or (buf[s + 2].toInt() and 0xFF)
        val pcrPid = ((buf[s + 8].toInt() and 0x1F) shl 8) or (buf[s + 9].toInt() and 0xFF)
        val programInfoLen = ((buf[s + 10].toInt() and 0x0F) shl 8) or (buf[s + 11].toInt() and 0xFF)
        var p = s + 12 + programInfoLen
        val end = minOf(s + 3 + sectionLength - 4, pos + TS_PACKET)
        val streams = ArrayList<Pair<Int, Int>>()
        while (p + 5 <= end) {
            val streamType = buf[p].toInt() and 0xFF
            val esPid = ((buf[p + 1].toInt() and 0x1F) shl 8) or (buf[p + 2].toInt() and 0xFF)
            val esInfoLen = ((buf[p + 3].toInt() and 0x0F) shl 8) or (buf[p + 4].toInt() and 0xFF)
            streams.add(streamType to esPid)
            p += 5 + esInfoLen
        }
        if (streams.isEmpty()) return null
        return TsProgram(pmtPid, pcrPid, streams)
    }

    // ================================================================
    // MPEG-TS: sintesis de PAT + PMT (prologo de cada segmento)
    // ================================================================

    private fun u16(v: Int): ByteArray = byteArrayOf(((v shr 8) and 0xFF).toByte(), (v and 0xFF).toByte())

    /**
     * Paquete TS de 188 bytes con una seccion PSI (PAT o PMT), con CRC32-MPEG
     * valido y stuffing 0xFF. Estandar ISO 13818-1.
     */
    private fun psiPacket(pid: Int, tableId: Int, body: ByteArray): ByteArray {
        val sectionLength = body.size + 4   // body + CRC
        val section = ByteArray(3 + body.size + 4)
        section[0] = tableId.toByte()
        section[1] = (0xB0 or ((sectionLength shr 8) and 0x0F)).toByte()
        section[2] = (sectionLength and 0xFF).toByte()
        System.arraycopy(body, 0, section, 3, body.size)
        val crc = crc32Mpeg(section, 0, 3 + body.size)
        section[3 + body.size] = ((crc ushr 24) and 0xFF).toByte()
        section[4 + body.size] = ((crc ushr 16) and 0xFF).toByte()
        section[5 + body.size] = ((crc ushr 8) and 0xFF).toByte()
        section[6 + body.size] = (crc and 0xFF).toByte()

        val pkt = ByteArray(TS_PACKET)
        pkt[0] = 0x47.toByte()
        pkt[1] = (0x40 or ((pid shr 8) and 0x1F)).toByte()   // PUSI=1
        pkt[2] = (pid and 0xFF).toByte()
        pkt[3] = 0x10.toByte()                                // AFC=01 (solo payload), CC=0
        pkt[4] = 0x00                                         // pointer_field
        val copyLen = minOf(section.size, TS_PACKET - 5)
        System.arraycopy(section, 0, pkt, 5, copyLen)
        java.util.Arrays.fill(pkt, 5 + copyLen, TS_PACKET, 0xFF.toByte())
        return pkt
    }

    /** CRC32-MPEG-2 (poly 0x04C11DB7, init 0xFFFFFFFF, sin reflexion). */
    private fun crc32Mpeg(data: ByteArray, from: Int, to: Int): Int {
        var crc = -0x1 // 0xFFFFFFFF
        for (i in from until to) {
            crc = crc xor ((data[i].toInt() and 0xFF) shl 24)
            for (k in 0 until 8) {
                crc = if (crc and Int.MIN_VALUE != 0) (crc shl 1) xor 0x04C11DB7 else crc shl 1
            }
        }
        return crc
    }

    /** 2 paquetes (376B): PAT (programa 1 → PMT) + PMT (PIDs y tipos REALES del archivo). */
    private fun buildTsPrologue(program: TsProgram): ByteArray {
        val patBody = byteArrayOf(
            0x00, 0x01,            // transport_stream_id = 1
            0xC1.toByte(),         // version 0 + current_next = 1
            0x00,                  // section_number
            0x00                   // last_section_number
        ) + u16(0x0001) + u16(0xE000 or program.pmtPid)   // programa 1 → PMT PID

        var pmtBody = ByteArray(0)
        pmtBody += u16(0x0001)                              // program_number
        pmtBody += byteArrayOf(0xC1.toByte(), 0x00, 0x00)   // version, section#, last#
        pmtBody += u16(0xE000 or program.pcrPid)            // PCR_PID
        pmtBody += u16(0xF000)                              // program_info_length = 0
        for ((streamType, esPid) in program.streams.take(MAX_SYNTH_STREAMS)) {
            pmtBody += byteArrayOf(streamType.toByte())
            pmtBody += u16(0xE000 or esPid)                 // elementary_PID
            pmtBody += u16(0xF000)                          // ES_info_length = 0
        }

        val pat = psiPacket(pid = 0x0000, tableId = 0x00, body = patBody)
        val pmt = psiPacket(pid = program.pmtPid, tableId = 0x02, body = pmtBody)
        return pat + pmt
    }

    // ================================================================
    // MPEG-TS: PCR (reloj del programa) para duraciones reales
    // ================================================================

    /** PCR base (unidades de 90kHz) del paquete en [pos], o null si no tiene. */
    private fun readPcr(data: ByteArray, pos: Int): Long? {
        val afc = (data[pos + 3].toInt() shr 4) and 0x03
        if (afc != 2 && afc != 3) return null                // sin adaptation field
        val afLen = data[pos + 4].toInt() and 0xFF
        if (afLen < 7 || afLen > 182) return null
        if (data[pos + 5].toInt() and 0x10 == 0) return null // PCR flag no seteado
        var pcrBase = 0L
        for (i in 0 until 4) {
            pcrBase = (pcrBase shl 8) or (data[pos + 6 + i].toLong() and 0xFF)
        }
        pcrBase = (pcrBase shl 1) or ((data[pos + 10].toLong() shr 7) and 0x01L)
        return pcrBase
    }

    /** Primer PCR (90kHz) en [startOffset, startOffset+maxLen). Lectura en chunks. */
    private fun findFirstPcr(raf: RandomAccessFile, startOffset: Long, pcrPid: Int, maxLen: Long): Long? {
        val remaining = raf.length() - startOffset
        if (remaining <= 0) return null
        val window = minOf(maxLen, remaining).toInt()
        if (window < TS_PACKET) return null

        val chunk = ByteArray(PCR_SCAN_CHUNK_BYTES)
        var scanned = 0
        var carry = ByteArray(0)
        while (scanned < window) {
            val toRead = minOf(chunk.size, window - scanned)
            raf.seek(startOffset + scanned)
            raf.readFully(chunk, 0, toRead)
            val data = if (carry.isEmpty()) carryOf(chunk, toRead) else carry + carryOf(chunk, toRead)
            val packets = data.size / TS_PACKET
            for (i in 0 until packets) {
                val pos = i * TS_PACKET
                if (data[pos].toInt() != 0x47) continue
                if (pidOf(data, pos) != pcrPid) continue
                readPcr(data, pos)?.let { return it }
            }
            val consumed = packets * TS_PACKET
            carry = data.copyOfRange(consumed, data.size)
            scanned += toRead
        }
        return null
    }

    private fun carryOf(src: ByteArray, len: Int): ByteArray = src.copyOf(len)

    // ================================================================
    // MPEG-TS: armado del indice
    // ================================================================

    private fun buildTsIndex(file: File, fileLen: Long, knownDurationMs: Long): LocalIndex? {
        val program = parseTsProgram(file) ?: run {
            Log.w(TAG, "buildTsIndex: PAT/PMT no parseable — el llamador usara el fallback byterange")
            return null
        }
        Log.i(TAG, "buildTsIndex: PMT pid=${program.pmtPid}, PCR pid=${program.pcrPid}, streams=${program.streams}")

        val prologue = buildTsPrologue(program)

        // Solo paquetes completos (la cola final < 188B se ignora)
        val usableLen = (fileLen / TS_PACKET) * TS_PACKET
        val segments = ArrayList<Segment>()
        var start = 0L
        while (start < usableLen) {
            val packets = if (segments.isEmpty()) TS_PACKETS_FIRST_SEGMENT else TS_PACKETS_PER_SEGMENT
            val end = minOf(start + packets * TS_PACKET, usableLen)
            segments.add(Segment(start, end - start))
            start = end
        }
        if (segments.isEmpty()) return null

        // PCR al inicio de cada segmento → duraciones reales
        val pcrs = arrayOfNulls<Long>(segments.size)
        val scanPid = if (program.pcrPid in 1..0x1FFE) program.pcrPid else -1
        if (scanPid > 0) {
            try {
                RandomAccessFile(file, "r").use { raf ->
                    for (i in segments.indices) {
                        pcrs[i] = findFirstPcr(raf, segments[i].offset, scanPid, PCR_SCAN_LIMIT_BYTES)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "buildTsIndex: error escaneando PCR (duraciones por estimacion): ${e.message}")
            }
        }

        val durations = computeDurations(segments, pcrs, 90000.0, knownDurationMs)
        val total = durations.sum()
        Log.i(
            TAG,
            "buildTsIndex: ${segments.size} segmentos autocontenidos, total=" +
                String.format(Locale.US, "%.1f", total) + "s, PCR=" + pcrs.count { it != null } + "/" + segments.size
        )
        return LocalIndex(
            isFmp4 = false,
            segments = segments,
            durationsSec = durations,
            tsPrologue = prologue,
            fmp4InitEnd = 0L,
            totalDurationSec = total,
        )
    }

    // ================================================================
    // Duraciones (comun TS/fMP4)
    // ================================================================

    /**
     * Duraciones por segmento:
     * 1. diff de timestamps consecutivos (PCR 90kHz / tfdt en timescale) si es sana;
     * 2. si falta → estimacion por bitrate (de lo cubierto o de la duracion conocida);
     * 3. el ultimo segmento cierra contra la duracion conocida del dispositivo.
     */
    private fun computeDurations(
        segments: List<Segment>,
        startTimes: Array<Long?>,
        unitsPerSecond: Double,
        knownDurationMs: Long,
    ): List<Double> {
        val n = segments.size
        val known = if (knownDurationMs > 0) knownDurationMs / 1000.0 else 0.0
        val totalBytes = if (n > 0) segments.sumOf { it.length }.toDouble() else 0.0

        val direct = arrayOfNulls<Double>(n)
        var bytesCovered = 0L
        var timeCovered = 0.0
        for (i in 0 until n - 1) {
            val a = startTimes[i]
            val b = startTimes[i + 1]
            if (a != null && b != null) {
                val d = (b - a) / unitsPerSecond
                if (d in MIN_SANE_SEGMENT_SEC..MAX_SANE_SEGMENT_SEC) {
                    direct[i] = d
                    bytesCovered += segments[i].length
                    timeCovered += d
                }
            }
        }

        var bytesPerSec = if (timeCovered > 1.0) bytesCovered / timeCovered else 0.0
        if (bytesPerSec <= 0.0 && known > 0.0 && totalBytes > 0.0) {
            bytesPerSec = totalBytes / known
        }

        val result = ArrayList<Double>(n)
        for (i in 0 until n) {
            val d = when {
                direct[i] != null -> direct[i]!!
                bytesPerSec > 0.0 -> segments[i].length / bytesPerSec
                else -> DEFAULT_SEGMENT_DURATION_SEC
            }
            result.add(d.coerceIn(MIN_SANE_SEGMENT_SEC, MAX_SANE_SEGMENT_SEC))
        }

        if (known > 0.0 && n > 0) {
            val sumExceptLast = if (n >= 2) result.subList(0, n - 1).sum() else 0.0
            if (n >= 2 && sumExceptLast > known * 0.5 && sumExceptLast < known * 1.5) {
                // timestamps confiables → el ultimo cierra la cuenta con la duracion real
                result[n - 1] = (known - sumExceptLast).coerceIn(MIN_SANE_SEGMENT_SEC, MAX_SANE_SEGMENT_SEC)
            } else if (totalBytes > 0.0) {
                // timestamps poco confiables → reparto proporcional al tamanio
                for (i in 0 until n) {
                    result[i] = (known * segments[i].length / totalBytes).coerceIn(MIN_SANE_SEGMENT_SEC, MAX_SANE_SEGMENT_SEC)
                }
            }
        }
        return result
    }

    // ================================================================
    // fMP4/CMAF
    // ================================================================

    private fun be32(b: ByteArray, off: Int): Long {
        return ((b[off].toLong() and 0xFF) shl 24) or
            ((b[off + 1].toLong() and 0xFF) shl 16) or
            ((b[off + 2].toLong() and 0xFF) shl 8) or
            (b[off + 3].toLong() and 0xFF)
    }

    private fun be64(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 0 until 8) {
            v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        }
        return v
    }

    private fun boxSize(buf: ByteArray, p: Int): Long = be32(buf, p)

    private fun boxType(buf: ByteArray, p: Int): String = String(buf, p, 4, Charsets.US_ASCII)

    private fun findBox(buf: ByteArray, from: Int, toExclusive: Int, type: String): Int? {
        var p = from
        while (p + 8 <= toExclusive) {
            val s = boxSize(buf, p)
            if (s < 8 || p + s > toExclusive) return null
            if (boxType(buf, p + 4) == type) return p
            p += s.toInt()
        }
        return null
    }

    private class Fmp4InitInfo(val videoTrackId: Long?, val timescale: Double)

    /** moov → track_ID y timescale del track de video (fallback: mvhd). */
    private fun parseFmp4Init(buf: ByteArray): Fmp4InitInfo? {
        val moov = findBox(buf, 0, buf.size, "moov") ?: return null
        val moovEnd = moov + boxSize(buf, moov).toInt()

        var fallbackTimescale = 0.0
        findBox(buf, moov + 8, moovEnd, "mvhd")?.let { mvhd ->
            val v = buf[mvhd + 8].toInt() and 0xFF
            fallbackTimescale = if (v == 1) be32(buf, mvhd + 20).toDouble() else be32(buf, mvhd + 12).toDouble()
        }

        var videoTrackId: Long? = null
        var videoTimescale = 0.0
        var p = moov + 8
        while (p + 8 <= moovEnd) {
            val s = boxSize(buf, p).toInt()
            if (s < 8 || p + s > moovEnd) break
            if (boxType(buf, p + 4) == "trak") {
                val trakEnd = p + s
                val mdia = findBox(buf, p + 8, trakEnd, "mdia")
                if (mdia != null) {
                    val mdiaEnd = mdia + boxSize(buf, mdia).toInt()
                    val isVideo = findBox(buf, mdia + 8, mdiaEnd, "hdlr")
                        ?.let { boxType(buf, it + 16) == "vide" } ?: false
                    var timescale = 0.0
                    findBox(buf, mdia + 8, mdiaEnd, "mdhd")?.let { mdhd ->
                        val v = buf[mdhd + 8].toInt() and 0xFF
                        timescale = if (v == 1) be32(buf, mdhd + 20).toDouble() else be32(buf, mdhd + 12).toDouble()
                    }
                    if (isVideo) {
                        findBox(buf, p + 8, trakEnd, "tkhd")?.let { tkhd ->
                            val v = buf[tkhd + 8].toInt() and 0xFF
                            videoTrackId = if (v == 1) be32(buf, tkhd + 20) else be32(buf, tkhd + 12)
                        }
                        if (timescale > 0.0) videoTimescale = timescale
                    }
                }
            }
            p += s
        }
        val ts = if (videoTimescale > 0.0) videoTimescale else fallbackTimescale
        if (ts <= 0.0) return null
        return Fmp4InitInfo(videoTrackId, ts)
    }

    /** tfdt del traf del track de video (o del primer traf) dentro del moof. */
    private fun readFragmentStartTime(raf: RandomAccessFile, moofOffset: Long, videoTrackId: Long?): Long? {
        return try {
            raf.seek(moofOffset)
            val hdr = ByteArray(8)
            raf.readFully(hdr)
            val moofSize = be32(hdr, 0)
            if (moofSize < 8 || moofSize > 8L * 1024 * 1024) return null
            val buf = ByteArray(moofSize.toInt())
            raf.seek(moofOffset)
            raf.readFully(buf)

            var firstTfdt: Long? = null
            var videoTfdt: Long? = null
            var pos = 8
            while (pos + 8 <= buf.size) {
                val s = boxSize(buf, pos).toInt()
                if (s < 8 || pos + s > buf.size) break
                if (boxType(buf, pos + 4) == "traf") {
                    var p2 = pos + 8
                    var trackId: Long? = null
                    var tfdt: Long? = null
                    while (p2 + 8 <= pos + s) {
                        val s2 = boxSize(buf, p2).toInt()
                        if (s2 < 8 || p2 + s2 > pos + s) break
                        when (boxType(buf, p2 + 4)) {
                            "tfhd" -> trackId = be32(buf, p2 + 12)
                            "tfdt" -> {
                                val version = buf[p2 + 8].toInt() and 0xFF
                                tfdt = if (version == 1) be64(buf, p2 + 12) else be32(buf, p2 + 12)
                            }
                        }
                        p2 += s2
                    }
                    if (tfdt != null) {
                        if (firstTfdt == null) firstTfdt = tfdt
                        if (videoTrackId != null && trackId == videoTrackId) {
                            videoTfdt = tfdt
                            break
                        }
                    }
                }
                pos += s
            }
            videoTfdt ?: firstTfdt
        } catch (e: Exception) {
            null
        }
    }

    private fun buildFmp4Index(file: File, fileLen: Long, knownDurationMs: Long): LocalIndex? {
        // Walk de cajas top-level: offsets de cada moof (fragmento) y styp (marcas)
        val moofStarts = ArrayList<Long>()
        val boundaries = ArrayList<Long>()   // moof | styp, ordenadas
        var firstMoof = -1L
        try {
            RandomAccessFile(file, "r").use { raf ->
                var pos = 0L
                val hdr = ByteArray(8)
                while (pos + 8 <= fileLen) {
                    raf.seek(pos)
                    raf.readFully(hdr)
                    var size = be32(hdr, 0)
                    if (size == 1L) {
                        val ext = ByteArray(8)
                        raf.readFully(ext)
                        size = be64(ext, 0)
                    }
                    if (size < 8 || pos + size > fileLen) {
                        Log.w(TAG, "buildFmp4Index: caja invalida en $pos — truncando walk")
                        break
                    }
                    when (String(hdr, 4, 4, Charsets.US_ASCII)) {
                        "moof" -> {
                            if (firstMoof < 0) firstMoof = pos
                            moofStarts.add(pos)
                            boundaries.add(pos)
                        }
                        "styp" -> boundaries.add(pos)
                    }
                    pos += size
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "buildFmp4Index: error en walk de cajas", e)
        }

        if (moofStarts.isEmpty() || firstMoof <= 0L) {
            Log.w(TAG, "buildFmp4Index: sin fragmentos o sin init — fallback byterange")
            return null
        }

        // init = [0, primera frontera) — recorta un styp previo al primer moof
        val initEnd = minOf(boundaries.first(), firstMoof)

        // Agrupar fragmentos en segmentos de ~4MB (cada grupo arranca en un moof)
        fun fragEndOf(k: Int): Long =
            if (k + 1 < moofStarts.size) {
                boundaries.firstOrNull { it > moofStarts[k] } ?: moofStarts[k + 1]
            } else {
                boundaries.firstOrNull { it > moofStarts[k] } ?: fileLen
            }

        val segments = ArrayList<Segment>()
        val groupFirstIdx = ArrayList<Int>()
        var i = 0
        while (i < moofStarts.size) {
            var bytes = 0L
            var j = i
            while (j < moofStarts.size) {
                bytes += fragEndOf(j) - moofStarts[j]
                if (bytes >= FMP4_GROUP_TARGET_BYTES) break
                if (j + 1 < moofStarts.size) j++ else break
            }
            val start = moofStarts[i]
            val end = fragEndOf(j)
            segments.add(Segment(start, end - start))
            groupFirstIdx.add(i)
            i = j + 1
        }
        if (segments.isEmpty()) return null

        // Duraciones por tfdt (timescale del track de video)
        var startTimes = arrayOfNulls<Long>(segments.size)
        var timescale = 0.0
        try {
            val initLen = initEnd.toInt()
            if (initLen in 1..(16 * 1024 * 1024)) {
                RandomAccessFile(file, "r").use { raf ->
                    val initBuf = ByteArray(initLen)
                    raf.seek(0L)
                    raf.readFully(initBuf)
                    val initInfo = parseFmp4Init(initBuf)
                    if (initInfo != null) {
                        timescale = initInfo.timescale
                        for (g in segments.indices) {
                            startTimes[g] = readFragmentStartTime(raf, moofStarts[groupFirstIdx[g]], initInfo.videoTrackId)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "buildFmp4Index: error parseando init/tfdt (duraciones estimadas): ${e.message}")
        }

        val durations = computeDurations(segments, startTimes, if (timescale > 0.0) timescale else 90000.0, knownDurationMs)
        val total = durations.sum()
        Log.i(
            TAG,
            "buildFmp4Index: ${moofStarts.size} fragmentos → ${segments.size} segmentos, init=${initEnd}B, " +
                "timescale=${timescale.toInt()}, total=" + String.format(Locale.US, "%.1f", total) + "s"
        )
        return LocalIndex(
            isFmp4 = true,
            segments = segments,
            durationsSec = durations,
            tsPrologue = null,
            fmp4InitEnd = initEnd,
            totalDurationSec = total,
        )
    }

    // ================================================================
    // Utilidades
    // ================================================================

    private fun alignDown(bytes: Long): Long = (bytes / TS_PACKET) * TS_PACKET

    private fun targetDuration(durations: List<Double>): Int {
        val max = durations.maxOrNull() ?: DEFAULT_SEGMENT_DURATION_SEC
        return maxOf(1, kotlin.math.ceil(max).toInt())
    }
}
