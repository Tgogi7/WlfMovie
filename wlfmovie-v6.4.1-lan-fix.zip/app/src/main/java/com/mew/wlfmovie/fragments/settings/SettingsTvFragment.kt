package com.mew.wlfmovie.fragments.settings

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.mew.wlfmovie.BuildConfig
import com.mew.wlfmovie.R
import com.mew.wlfmovie.databinding.FragmentSettingsTvBinding
import com.mew.wlfmovie.utils.AccountManager
import com.mew.wlfmovie.utils.SyncManager
import com.mew.wlfmovie.utils.SupabaseClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsTvFragment : Fragment() {

    private var _binding: FragmentSettingsTvBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsTvBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Glide.with(this).load(R.drawable.ic_wlfmovie_logo).into(binding.ivSettingsLogo)
        binding.tvSettingsVersion.text = "Versión ${BuildConfig.VERSION_NAME}"

        // WLFMOVIE V6.2: Recopilador de errores. Visible SOLO en DEBUG.
        // En release no hay ni crash logger ni dialogo — el build oficial queda
        // limpio para el usuario final.
        if (BuildConfig.DEBUG) {
            binding.btnSettingsDebugErrors.visibility = View.VISIBLE
            binding.btnSettingsDebugErrors.text = getString(R.string.debug_errors_button)
            binding.btnSettingsDebugErrors.setOnClickListener {
            val count = com.mew.wlfmovie.utils.CrashLogger.count()
            val fullText = com.mew.wlfmovie.utils.CrashLogger.getErrorsAsText()
            val message = if (count == 0) {
                getString(R.string.debug_errors_empty)
            } else {
                getString(R.string.debug_errors_dialog_title, count) + "\n\n" +
                    fullText.take(20_000)
            }
            android.app.AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.debug_errors_dialog_title, count))
                .setMessage(message)
                .setPositiveButton(R.string.debug_errors_clear) { _, _ ->
                    android.app.AlertDialog.Builder(requireContext())
                        .setTitle(R.string.debug_errors_clear_confirm)
                        .setPositiveButton(R.string.debug_errors_clear_yes) { _, _ ->
                            com.mew.wlfmovie.utils.CrashLogger.clear()
                            Toast.makeText(
                                requireContext(),
                                R.string.debug_errors_clear_done,
                                Toast.LENGTH_SHORT,
                            ).show()
                        }
                        .setNegativeButton(R.string.debug_errors_clear_no, null)
                        .show()
                }
                .setNegativeButton(R.string.debug_errors_copy_all) { _, _ ->
                    val clipboard = requireContext()
                        .getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                        as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("WlfMovie Errors", fullText)
                    )
                    Toast.makeText(
                        requireContext(),
                        R.string.debug_errors_copied_toast,
                        Toast.LENGTH_SHORT,
                    ).show()
                }
                .setNeutralButton(android.R.string.cancel, null)
                .show()
            }
        }

        binding.btnSettingsLogin.setOnClickListener {
            showAuthDialog(isLogin = true)
        }

        binding.btnSettingsSync.setOnClickListener {
            performSync()
        }

        binding.btnSettingsLogout.setOnClickListener {
            AccountManager.clearSession(requireContext())
            updateUI()
            Toast.makeText(requireContext(), "Sesión cerrada", Toast.LENGTH_SHORT).show()
        }

        binding.btnSettingsTerms.setOnClickListener {
            showTermsDialog()
        }

        updateUI()
    }

    private fun updateUI() {
        val session = AccountManager.getSession(requireContext())
        if (session != null) {
            binding.tvSettingsUsername.text = session.username
            binding.btnSettingsLogin.visibility = View.GONE
            binding.btnSettingsSync.visibility = View.VISIBLE
            binding.btnSettingsLogout.visibility = View.VISIBLE

            val lastSync = AccountManager.getLastSync(requireContext())
            if (lastSync != null) {
                binding.tvSettingsLastSync.visibility = View.VISIBLE
                binding.tvSettingsLastSync.text = "Última sync: ${com.mew.wlfmovie.utils.SyncManager.formatLastSync(lastSync)}"
            } else {
                binding.tvSettingsLastSync.visibility = View.GONE
            }
        } else {
            binding.tvSettingsUsername.text = "Sin usuario"
            binding.btnSettingsLogin.visibility = View.VISIBLE
            binding.btnSettingsSync.visibility = View.GONE
            binding.btnSettingsLogout.visibility = View.GONE
            binding.tvSettingsLastSync.visibility = View.GONE
        }
    }

    private fun showAuthDialog(isLogin: Boolean) {
        val dialog = Dialog(requireContext())
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_auth, null)

        val tvTitle = dialogView.findViewById<TextView>(R.id.tv_auth_title)
        val etEmail = dialogView.findViewById<EditText>(R.id.et_auth_email)
        val etUsername = dialogView.findViewById<EditText>(R.id.et_auth_username)
        val etPassword = dialogView.findViewById<EditText>(R.id.et_auth_password)
        val btnAction = dialogView.findViewById<TextView>(R.id.btn_auth_action)
        val tvError = dialogView.findViewById<TextView>(R.id.tv_auth_error)
        val tvToggle = dialogView.findViewById<TextView>(R.id.tv_auth_toggle)

        // TV: focusables
        etEmail.isFocusable = true
        etEmail.isFocusableInTouchMode = true
        etPassword.isFocusable = true
        etPassword.isFocusableInTouchMode = true
        etUsername.isFocusable = true
        etUsername.isFocusableInTouchMode = true
        btnAction.isFocusable = true
        btnAction.isFocusableInTouchMode = true
        tvToggle.isFocusable = true
        tvToggle.isFocusableInTouchMode = true

        var currentIsLogin = isLogin
        fun updateDialogMode(loginMode: Boolean) {
            currentIsLogin = loginMode
            if (loginMode) {
                tvTitle.text = "Iniciar sesión"
                btnAction.text = "Iniciar sesión"
                etUsername.visibility = View.GONE
                tvToggle.text = "¿No tienes cuenta? Regístrate"
            } else {
                tvTitle.text = "Registrarse"
                btnAction.text = "Registrarse"
                etUsername.visibility = View.VISIBLE
                tvToggle.text = "¿Ya tienes cuenta? Inicia sesión"
            }
            tvError.visibility = View.GONE
        }
        updateDialogMode(isLogin)

        tvToggle.setOnClickListener {
            updateDialogMode(!currentIsLogin)
        }

        btnAction.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val username = etUsername.text.toString().trim()

            tvError.visibility = View.GONE

            if (email.isBlank() || password.isBlank()) {
                tvError.text = "Completa todos los campos"
                tvError.visibility = View.VISIBLE
                return@setOnClickListener
            }

            if (!currentIsLogin && username.isBlank()) {
                tvError.text = "Elige un nombre de usuario"
                tvError.visibility = View.VISIBLE
                return@setOnClickListener
            }

            if (!AccountManager.isValidEmail(email)) {
                tvError.text = "Email no válido"
                tvError.visibility = View.VISIBLE
                return@setOnClickListener
            }

            if (password.length < 6) {
                tvError.text = "La contraseña debe tener al menos 6 caracteres"
                tvError.visibility = View.VISIBLE
                return@setOnClickListener
            }

            btnAction.text = "Procesando..."
            btnAction.isEnabled = false

            lifecycleScope.launch {
                val result = if (currentIsLogin) {
                    SupabaseClient.login(email, password)
                } else {
                    SupabaseClient.register(email, password, username)
                }

                when (result) {
                    is SupabaseClient.AuthResult.Success -> {
                        val user = result.user
                        AccountManager.saveSession(requireContext(), user.id, user.email, user.username)
                        if (currentIsLogin) {
                            SyncManager.download(requireContext(), clearFirst = true)
                        } else {
                            SyncManager.upload(requireContext())
                        }
                        withContext(Dispatchers.Main) {
                            dialog.dismiss()
                            updateUI()
                            Toast.makeText(requireContext(), "Bienvenido, ${user.username}!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    is SupabaseClient.AuthResult.Error -> {
                        withContext(Dispatchers.Main) {
                            tvError.text = result.message
                            tvError.visibility = View.VISIBLE
                            btnAction.text = if (currentIsLogin) "Iniciar sesión" else "Registrarse"
                            btnAction.isEnabled = true
                        }
                    }
                }
            }
        }

        dialog.setContentView(dialogView)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    private fun performSync() {
        binding.pbSettingsLoading.visibility = View.VISIBLE
        binding.btnSettingsSync.isEnabled = false
        binding.btnSettingsSync.text = "Sincronizando..."

        lifecycleScope.launch {
            val uploadOk = SyncManager.upload(requireContext())
            val downloadOk = SyncManager.download(requireContext(), clearFirst = false)

            withContext(Dispatchers.Main) {
                binding.pbSettingsLoading.visibility = View.GONE
                binding.btnSettingsSync.isEnabled = true
                binding.btnSettingsSync.text = "Sincronizar ahora"

                if (uploadOk && downloadOk) {
                    Toast.makeText(requireContext(), "Sincronización completada", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Error en la sincronización", Toast.LENGTH_SHORT).show()
                }
                updateUI()
            }
        }
    }

    private fun showTermsDialog() {
        val dialog = Dialog(requireContext())
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.wlf_dialog_list, null)

        dialogView.findViewById<TextView>(R.id.tv_dialog_title).text = "Términos y condiciones"

        val container = dialogView.findViewById<android.widget.LinearLayout>(R.id.ll_dialog_items)
        val termsText = TextView(requireContext()).apply {
            text = SettingsMobileFragment.TERMS_AND_CONDITIONS
            textSize = 13f
            setTextColor(0xFFB8B8D1.toInt())
            setPadding(16, 24, 16, 24)
            setLineSpacing(4f, 1f)
        }
        container.addView(termsText)

        dialog.setContentView(dialogView)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
