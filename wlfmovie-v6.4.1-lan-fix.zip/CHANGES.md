# WlfMovie V6.4.1 — Fix crash en primer arranque + Fix "Enviar a PC" que se cortaba a los 2-3s

ZIP ACUMULATIVO: contiene TODO lo de v6.4.0 + estos cambios.
Copie la carpeta `app/` completa sobre la raíz de su proyecto (reemplaza archivos).

Si ya tiene v6.4.0 compilado, copie estos **10 archivos** (7 NUEVOS en el zip + 3 modificados):

1. `app/src/main/java/com/mew/wlfmovie/utils/DnsResolver.kt` ← reescrito (fix crash)
2. `app/src/main/java/com/mew/wlfmovie/utils/UserPreferences.kt` (guards anti-race)
3. `app/src/main/java/com/mew/wlfmovie/utils/AniWorldUpdateTvShowWorker.kt` (sin init eager)
4. `app/src/main/java/com/mew/wlfmovie/providers/AniWorldProvider.kt` (cliente lazy)
5. `app/src/main/java/com/mew/wlfmovie/providers/OtakufrProvider.kt` (cliente lazy)
6. `app/src/main/java/com/mew/wlfmovie/providers/RidomoviesProvider.kt` (cliente lazy)
7. `app/src/main/java/com/mew/wlfmovie/providers/AnikotoProvider.kt` (cliente lazy)
8. `app/src/main/java/com/mew/wlfmovie/StreamFlixApp.kt` (try/catch al configurar DNS)
9. `app/src/main/java/com/mew/wlfmovie/remoteplay/LocalMediaPlaylist.kt` ← reescrito (fix HLS)
10. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayServer.kt` (nueva ruta /localsegment)

## FIX 1 — Crash FATAL la primera vez que se abre la app

Error reportado: `NoClassDefFoundError: com.mew.wlfmovie.utils.DnsResolver`
en `StreamFlixApp.onCreate` → la app se cerraba sola al entrar.

### Por qué pasaba (condena de inicialización en cadena)
1. Al primer arranque, WorkManager puede crear `AniWorldUpdateTvShowWorker`
   en un hilo propio ANTES de que `App.onCreate()` termine.
2. El constructor del worker referenciaba `AniWorldProvider` → eso ejecutaba
   el init de la clase del provider, que construía SU cliente OkHttp de forma
   EAGER (al cargar la clase).
3. Ese cliente usaba `DnsResolver` → el init de `DnsResolver` leía
   `UserPreferences.dohProviderUrl`... pero `UserPreferences.setup()` TODAVÍA
   no había corrido → `UninitializedPropertyAccessException`.
4. Eso envenenaba la clase `DnsResolver` (ExceptionInInitializerError) y
   cuando el hilo principal llegaba a `DnsResolver.setDnsUrl(...)` →
   **NoClassDefFoundError → FATAL**.

### El fix (3 capas, para que no pueda volver a pasar)
- **`DnsResolver`**: su inicialización ya NO toca `UserPreferences` ni
  construye nada — arranca con DNS del sistema (trivial, a prueba de fallos);
  el cliente DoH se construye lazy y con try/catch.
- **4 providers** (AniWorld, Otakufr, Ridomovies, Anikoto): el cliente ya no
  se construye al cargar la clase — `by lazy` (se construye en el primer uso
  real, siempre después del arranque). El worker tampoco referencia el
  provider en su constructor.
- **Escudo extra**: `App.onCreate` envuelve la configuración de DNS en
  try/catch (un fallo de DNS jamás vuelve a tumbar el arranque) y TODOS los
  accesores de `UserPreferences.Key` devuelven el valor por defecto si algo
  los toca antes del setup, en vez de explotar.

## FIX 2 — "Enviar a PC" de una descarga se cortaba a los 2-3 segundos

Error reportado en el navegador del PC:
`HLS fatal error: fragParsingError — "Found no media in fragment 1"`
(hls.js reintentaba 6 veces y moría).

### Por qué pasaba
La V6.4.0 partía el `.ts` en trozos por rango de bytes (`#EXT-X-BYTERANGE`).
El problema: en un MPEG-TS el "mapa de pistas" (paquetes PAT/PMT) está SOLO al
principio del archivo. El primer trozo reproducía bien, pero cuando hls.js
reiniciaba su demuxer (algo normal tras un reintento o seek), el trozo 2 en
adelante ya no tenía mapa → "no encontré media" → error fatal.

### El fix — segmentos AUTOCONTENIDOS (como un HLS de verdad)
- Se parsea el PAT/PMT REAL del archivo (PIDs y tipos de stream exactos).
- Se sintetizan 2 mini-paquetes (PAT + PMT, con CRC válido) que se ANTEPONEN
  a CADA segmento servido → cada segmento es un segmento HLS TS válido e
  independiente. El demuxer puede reiniciarse mil veces: siempre reencuentra
  el mapa. Es exactamente cómo están construidos los HLS reales.
- Cada segmento tiene su propia URL (`/localsegment?i=N`) — cero dependencia
  de byteranges encadenados.
- **Duraciones reales**: los `#EXTINF` se calculan con los timestamps PCR del
  stream (no uniformes) → el seek en el PC es preciso y la barra de duración
  cierra contra la duración que conoce el teléfono.
- **fMP4/CMAF** (si el .ts es de cajas MP4): init por `#EXT-X-MAP`, fragmentos
  agrupados por cajas moof/mdat, duraciones por tfdt del track de video.
- Fallback: si un archivo no se puede indexar, se sirve el m3u8 de la V6.4.0
  (mismo comportamiento de antes, nunca peor).

### Qué NO cambió
- El modo ONLINE (compartir película en línea) quedó intacto línea por línea.
- La web del PC no cambió ni un byte (sigue usando el mismo hls.js).
- El guardado de progreso sigue SOLO en Descargas (sin sync, sin nube).
- Sigue funcionando 100% sin internet (hotspot/LAN): ningún byte sale a fuera.

## Cómo probar
1. **Crash**: desinstale la app, instale este build y ábrala — debe entrar
   limpia al primer intento (antes crasheaba justo ahí).
2. **Enviar a PC**: reproduzca una película DESCARGADA → "Enviar a PC" →
   abra la URL en el PC del mismo WiFi/hotspot → debe reproducir completa,
   con seek, pausa y barra de progreso (antes moría a los 2-3s).
3. **Sin internet**: active el hotspot del celular SIN datos, conecte el PC
   al hotspot y repita la prueba 2 — tiene que funcionar igual.
4. **Online sin regresión**: comparta una película ONLINE al PC — debe
   comportarse exactamente igual que en v6.4.0.

Logs clave (logcat): `buildTsIndex: N segmentos autocontenidos, total=...s`,
`serveLocalStream: m3u8 N segmentos autocontenidos`, `DnsResolver` ya no
debería aparecer en ningún FATAL.
