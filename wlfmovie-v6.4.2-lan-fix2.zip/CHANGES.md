# WlfMovie V6.4.2 — Fix definitivo "Enviar descarga al PC": carga infinita / bufferAppendError

ZIP ACUMULATIVO: contiene TODO lo de v6.4.1 + estos cambios.
Copie la carpeta `app/` completa sobre la raíz de su proyecto (reemplaza archivos).

Si ya tiene v6.4.1 compilado, copie estos **3 archivos** (todos MODIFICADOS):

1. `app/src/main/java/com/mew/wlfmovie/remoteplay/LocalMediaPlaylist.kt` ← reescrito (v3)
2. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayServer.kt` (headers no-cache)
3. `app/src/main/assets/remote_player/app.js` ← NUEVO EN EL ZIP (player web del PC)

> IMPORTANTE: el archivo 3 es el reproductor que el celular le sirve al PC.
> Si su proyecto no tiene la carpeta `app/src/main/assets/remote_player/`,
> copie los 4 archivos de esa carpeta desde el proyecto fuente completo
> (index.html, app.js, styles.css, hls.min.js) — solo app.js cambió.

## EL BUG (error reportado en la consola del PC)

```
HLS fatal error: bufferAppendError
err: Error: audio SourceBuffer error. MediaSource readyState: ended
frag: { _url: 'http://IP:8080/localfile', _byteRange: [...], ... }
```

Análisis del código de hls.js 1.5.17 (el que trae la app):
1. El m3u8 servido seguía siendo el FALLBACK VIEJO (byteranges sobre /localfile)
   → el indexador nuevo de la v6.4.1 fallaba silenciosamente para ese archivo
   y caía al camino viejo.
2. Ese fallback declaraba duraciones EXTINF inventadas (6s planos — un .ts
   crudo no tiene duración para el player Android) → el TOTAL declarado del
   playlist quedaba MENOR que el contenido real del archivo.
3. hls.js ve el buffer "pasado" del final declarado → dispara endOfStream()
   → el MediaSource queda "ended" → el append de audio del MISMO segmento
   explota con bufferAppendError FATAL → pantalla de error o carga infinita.
4. Bonus bug: el navegador del PC cacheaba index.html/app.js sin headers
   no-cache → "reinstalé la app y sigue igual" (el PC seguía con el player
   viejo).

## LOS FIXES

### LocalMediaPlaylist.kt v3 (reescrito)
- **Sync robusto**: detecta la grilla real de paquetes TS (stride 188/192/204
  + residuo) escaneando el archivo — soporta init CMAF mezclado con TS,
  basura al inicio y M2TS. Antes: si el byte 0 no era 0x47 alineado a 188,
  el parseo de PAT/PMT fallaba → fallback roto.
- **Prólogo PAT/PMT VERBATIM**: en vez de sintetizar el PMT, copia los
  paquetes PAT/PMT ORIGINALES del archivo y los antepone a cada segmento
  (fidelidad total; soporta PMT multipaquete). Cada /localsegment sigue
  siendo autocontenido.
- **Duraciones ancladas a PCR reales**: primer PCR + muestreo + último PCR
  (escaneo de cola) → el total declarado del m3u8 ≈ duración REAL del
  archivo. Nunca menor (mataría con endOfStream) ni absurdo. Sin PCR y sin
  duración conocida → estimación conservadora (total largo, inocuo).
- **I/O acotado**: ~15MB de lecturas máximo para indexar cualquier tamaño
  (antes hasta 92MB+ en archivos grandes → timeout del manifest en el PC).
- **Mixto init+TS**: si el sniff dice fMP4 pero no hay cajas moof, prueba el
  camino TS antes de rendirse (antes: fallback roto directo).
- Comentarios de versión dentro del m3u8: abriendo `http://IP:8080/stream`
  en el navegador del PC se ve qué build lo sirvió y qué camino tomó
  ("local-segments" = bueno / "legacy-byterange" = fallback).

### RemotePlayServer.kt
- `Cache-Control: no-cache, no-store, must-revalidate` en index.html,
  assets, /info y los m3u8 del modo local → el PC SIEMPRE recibe el player
  y el manifest vigentes (adiós al caché fantasma tras actualizar).
- Camino online INTACTO (solo se tocaron respuestas del modo local y assets
  estáticos).

### app.js (player web del PC)
- **Carga única**: espera hasta 1.5s el video_info del WebSocket antes de
  cargar por /info (el celular lo manda al conectar). Antes cargaba el video
  dos veces y la segunda destrucción de hls.js dejaba el SourceBuffer en
  estados inconsistentes.
- **Auto-recuperación**: ante un mediaError fatal (bufferAppendError y
  similares) intenta `recoverMediaError()` hasta 2 veces antes de mostrar
  error.
- Log de versión al cargar (`app.js V6.4.2`).

## CÓMO PROBAR

1. Compilar e instalar la app en el celular.
2. En el PC: abrir la URL del cast y hacer **Ctrl+F5** (forzar refresco) la
   primera vez tras actualizar.
3. Reproducir la película descargada → "Enviar a PC" → debe reproducir
   completa, con seek y pausa.
4. Si algo falla: abrir `http://IP:8080/stream` directo en el PC:
   - línea `# WlfMovie V6.4.2 local-segments` → camino correcto activo.
   - línea `legacy-byterange` → el archivo no es indexable (mandar captura).
   - Sin línea de versión → el celular sigue corriendo un build viejo.

## NOTA SOBRE "REINSTALAR LA APP"
Reinstalar NO borra nada relevante: el bug era de código (y del caché del
navegador del PC). Con esta versión: app actualizada + Ctrl+F5 en el PC.
