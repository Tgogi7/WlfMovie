# WlfMovie V6.4.3 — Fix "Enviar descarga al PC": muere en el fragmento 23/24/25 sin la pestaña abierta

ZIP ACUMULATIVO: contiene TODO lo de v6.4.2 + estos cambios.
Copie la carpeta `app/` completa sobre la raíz de su proyecto (reemplaza archivos).

Si ya tiene v6.4.2 compilado, copie estos **4 archivos**:

1. `app/src/main/java/com/mew/wlfmovie/remoteplay/RemotePlayServer.kt` ← registro de índices por versión
2. `app/src/main/java/com/mew/wlfmovie/remoteplay/LocalMediaPlaylist.kt` ← m3u8 con URLs relativas versionadas
3. `app/src/main/assets/remote_player/app.js` ← cache-buster + anti-recargas por reconexión WS
4. `app/src/main/assets/remote_player/index.html` ← assets versionados (?v=6.4.3)

## EL BUG (lo que reportaste)

Síntomas:
- Con la pestaña de "enviar descarga al PC" abierta, `/stream` andaba perfecto
  (incluso adelantando al minuto 19).
- En el player normal, la reproducción moría en el **fragmento 23/24/25** con
  `fragParsingError: "Found no media in fragment"`.
- Un intento de 29s en `/stream` que el celular **ni registró como conexión**.

Diagnóstico (auditoría completa del server): TRES problemas viviendo juntos —
ninguno visible con la pestaña abierta, todos golpeando juntos al cerrarla:

1. **Los segmentos dependían del estado de la SESIÓN, no del m3u8.**
   `/localsegment` resolvía el archivo desde `RemotePlayState.localFilePath`
   (estado que cambia/resetea con cada cast) y el índice cacheado tenía en su
   clave `currentDuration` — un valor que **se reescribe en cada reporte de
   posición del PC** (`updateRemotePosition`). Resultado: el índice se podía
   reconstruir EN PLENA REPRODUCCIÓN y los bytes servidos dejaban de
   corresponder al m3u8 que el player ya tenía descargado. Cuando la sesión
   original estaba viva (pestaña abierta) todo coincidía; al cerrarla,
   cualquier cambio de estado servía bytes de otro índice/archivo bajo las
   mismas URLs → "Found no media in fragment".
2. **El m3u8 incrustaba URLs ABSOLUTAS con la IP del celular.** En un teléfono
   con Wi-Fi + hotspot activos a la vez (o si la IP cambia), `/stream` llegaba
   por la interfaz buena pero los segmentos apuntaban a la otra → los pedidos
   de segmentos fallaban aunque el manifest hubiera cargado.
3. **Caché del navegador del PC.** Los builds anteriores a 6.4.2 no mandaban
   headers anti-caché en `/stream` ni en los segmentos → el PC podía reponer
   un m3u8/segmentos VIEJOS sin que el celular viera una sola conexión (el
   "fantasma" de los 29s — reproducía desde lo cacheado y moría al agotarlo,
   cayendo de vuelta en el bug de la v6.4.0: byteranges crudos sin PAT/PMT →
   fragParsingError).
4. **Bonus**: cada RECONEXIÓN del WebSocket (pasa seguido en hotspot con
   power-save) hacía que el celular re-enviara `video_info` y la página
   **destruía y recargaba TODO el video** — buffer perdido, re-pedido del
   manifest, reconstrucción de índice... sesiones frágiles y cortes "al azar".

## LOS FIXES

### RemotePlayServer.kt — registro de índices POR VERSIÓN (el corazón)
- Nuevo registro: cada archivo indexado se guarda con clave de **identidad
  estable** (`path|len|mtime`, sin valores mutables) y una **versión** (hash
  de 8 hex). Se conservan los últimos 3 archivos (LRU).
- `/localsegment?v=X&i=N` resuelve el archivo y el índice **POR VERSIÓN**,
  no por sesión. Aunque cierres la pestaña, re-castees OTRA película o la
  sesión se reinicie: los bytes servidos SIEMPRE corresponden al m3u8 que el
  player tiene en la mano. Versión desconocida → 404 claro (nunca bytes de
  otro archivo). Sin `?v` (compatibilidad) → archivo actual de la sesión.
- `/stream?v=X` y `/localfile?v=X` también resuelven por versión.
- Duración FUERA de la clave del índice: se indexa UNA vez por archivo (se
  acabaron las reconstrucciones en mitad de la reproducción).
- Headers anti-caché completos en TODAS las respuestas locales:
  `Cache-Control: no-cache, no-store, must-revalidate, max-age=0` + `Pragma:
  no-cache` + `Expires: 0` (también en /info, /assets, index).
- Logs de diagnóstico: cada segmento 0/último/cada 100 se loguea con su
  versión, offset y tamaño; los 404/503 explican POR QUÉ. Si algo vuelve a
  fallar, el logcat del celular dice exactamente dónde se rompió.

### LocalMediaPlaylist.kt — m3u8 con URLs relativas y versionadas
- URLs de segmento: `localsegment?v=HASH&i=N` (relativas → se resuelven
  contra el host por el que llegó el request; inmune a IP/doble interfaz).
- `#EXT-X-MAP` relativo versionado para fMP4 (`localsegment?v=X&i=init`).
- El fallback legacy también usa URL relativa (`localfile`).
- Comentario de versión: abrí `http://IP:8080/stream` en el navegador del PC
  y la 2ª línea dice el build + la versión del índice (debug remoto).

### app.js V6.4.3 — cache-buster + anti-tormenta-de-recargas
- El manifest se pide como `/stream?cb=<timestamp>` (URL única por carga →
  el navegador NO puede reponerlo de su caché; ídem `/info`).
- **Guard anti-recarga**: si llega `video_info` del MISMO video que ya está
  cargado y sano (sin error, drift < 60s), NO se recarga nada — la
  reconexión del WS pasa invisible. Drift >= 60s → seek sin recargar.
  Video nuevo o error visible → recarga completa (como antes).
- `stop` limpia la clave del video cargado (el próximo video_info recarga).

### index.html — assets versionados
- `app.js?v=6.4.3`, `hls.min.js?v=6.4.3`, `styles.css?v=6.4.3`: tras
  actualizar la app, la URL nueva fuerza al navegador del PC a bajar el
  player nuevo aunque ignore los headers anti-caché (adiós "reinstalé y
  sigue igual").

## QUÉ ESPERAR (prueba sugerida)

1. Instalá v6.4.3, abrí la película descargada → "Enviar a PC".
2. En el PC: **Ctrl+F5** una sola vez en la página del player (para sacar
   cualquier app.js/index.html viejo de antes de este build).
3. Probá el caso que fallaba: cerrá la pestaña, dejá que el celular vuelva
   al player, y volvé a abrir la URL en el PC (o pegá `/stream` en VLC/mpv).
   Debe reproducir completo, con seek, sin importar el estado de la sesión.
4. Prueba extra: mientras reproduce en el PC, castear OTRA película desde
   el celular — el player del PC NO debe romperse (el registro de versiones
   le sigue sirviendo SU película hasta 2 casts después).

Si algo falla de nuevo: abrí `http://IP:8080/stream` en el navegador del PC
— la segunda línea muestra el build y la versión (v=…). Con eso + el logcat
(filtrá `WlfMovie-RemoteServer`) se ve exactamente qué camino tomó.
